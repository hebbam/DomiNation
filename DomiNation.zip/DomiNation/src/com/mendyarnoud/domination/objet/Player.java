package com.mendyarnoud.domination.objet;

public class Player {

	private String name;
	private String id;
	
	public void play() {
		
	}
}
