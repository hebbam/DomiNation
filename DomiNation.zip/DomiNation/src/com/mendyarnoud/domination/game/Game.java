package com.mendyarnoud.domination.game;

import java.util.ArrayList;
import java.util.List;

import com.mendyarnoud.domination.objet.Domino;
import com.mendyarnoud.domination.objet.Player;

public class Game {

	private List<Player> players = new ArrayList<>();
	private List<Domino> dominos = new ArrayList<>();
	
	public void start() {
		
	}
	
	public void pause() {
		
	}
	
	public void resume() {
		
	}
	
	public void stop() {
		
	}
}
